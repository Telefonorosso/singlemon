// HDMIKVM POC2 FIX5 - DDC/CI-controlled Windows -> AmigaOS input sender.
// AKVM/1 UDP protocol compatible with l3-netkeys-v1.1 (unchanged Amiga receiver).
// Source is intended for .NET Framework 4.x / Windows 10 or 11.
// Safe defaults: source read-only; no reset packets; capture explicitly opt-in.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace HDMIInputProbe
{
    internal static class NativeInput
    {
        internal const int WH_KEYBOARD_LL = 13;
        internal const int WH_MOUSE_LL = 14;
        internal const int WM_INPUT = 0x00FF;
        internal const int WM_CLOSE = 0x0010;
        internal const int WM_KEYDOWN = 0x0100;
        internal const int WM_KEYUP = 0x0101;
        internal const int WM_SYSKEYDOWN = 0x0104;
        internal const int WM_SYSKEYUP = 0x0105;
        internal const uint RID_INPUT = 0x10000003;
        internal const uint RIDEV_INPUTSINK = 0x00000100;
        internal const uint LLKHF_EXTENDED = 0x01;
        internal const uint LLKHF_INJECTED = 0x10;
        internal const int VK_F12 = 0x7B;
        internal const int VK_LSHIFT = 0xA0;
        internal const int VK_RSHIFT = 0xA1;
        internal const int VK_LWIN = 0x5B;
        internal const int VK_RWIN = 0x5C;
        internal const int VK_APPS = 0x5D; // Application/Menu key beside Right Alt
        internal const int VK_LMENU = 0xA4; // Left Alt / Option
        internal const int VK_RMENU = 0xA5; // Right Alt / AltGr

        [StructLayout(LayoutKind.Sequential)]
        internal struct KbdLlData
        {
            internal uint vkCode;
            internal uint scanCode;
            internal uint flags;
            internal uint time;
            internal IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct RawInputDevice
        {
            internal ushort usagePage;
            internal ushort usage;
            internal uint flags;
            internal IntPtr target;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct RawHeader
        {
            internal uint type;
            internal uint size;
            internal IntPtr device;
            internal IntPtr wParam;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct RawMouse
        {
            internal ushort flags;
            internal ushort padding;  // RAWMOUSE union alignment
            internal uint buttons;    // LOWORD = button flags, HIWORD = wheel data
            internal uint rawButtons;
            internal int dx;
            internal int dy;
            internal uint extra;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct RawMouseInput
        {
            internal RawHeader header;
            internal RawMouse mouse;
        }

        internal delegate IntPtr HookProc(int code, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        internal static extern IntPtr SetWindowsHookEx(int id, HookProc callback, IntPtr module, uint threadId);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool UnhookWindowsHookEx(IntPtr handle);
        [DllImport("user32.dll")]
        internal static extern IntPtr CallNextHookEx(IntPtr handle, int code, IntPtr wp, IntPtr lp);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        internal static extern IntPtr GetModuleHandle(string module);
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool RegisterRawInputDevices(
            [In] RawInputDevice[] devices, uint count, uint size);
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern uint GetRawInputData(IntPtr raw, uint command, IntPtr buffer,
            ref uint size, uint headerSize);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool PostMessage(IntPtr handle, uint message, IntPtr wp, IntPtr lp);
    }

    internal sealed class InputWindow : NativeWindow, IDisposable
    {
        private readonly Action<NativeInput.RawMouse> _onMouse;
        internal InputWindow(Action<NativeInput.RawMouse> onMouse)
        {
            _onMouse = onMouse;
            CreateParams cp = new CreateParams();
            cp.Caption = "HDMIKVM Raw Input Sink";
            CreateHandle(cp);
            NativeInput.RawInputDevice[] devices = new NativeInput.RawInputDevice[] {
                new NativeInput.RawInputDevice {
                    usagePage = 1, usage = 2, flags = NativeInput.RIDEV_INPUTSINK,
                    target = Handle
                }
            };
            if (!NativeInput.RegisterRawInputDevices(devices, 1,
                    (uint)Marshal.SizeOf(typeof(NativeInput.RawInputDevice))))
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(),
                    "RegisterRawInputDevices failed");
        }
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == NativeInput.WM_INPUT)
            {
                ReadRawInput(m.LParam);
            }
            else if (m.Msg == NativeInput.WM_CLOSE)
            {
                Application.ExitThread();
            }
            base.WndProc(ref m); // required for raw-input resource cleanup
        }
        private void ReadRawInput(IntPtr handle)
        {
            uint size = 0;
            uint hsize = (uint)Marshal.SizeOf(typeof(NativeInput.RawHeader));
            uint n = NativeInput.GetRawInputData(handle, NativeInput.RID_INPUT,
                IntPtr.Zero, ref size, hsize);
            if (n == uint.MaxValue || size < (uint)Marshal.SizeOf(typeof(NativeInput.RawMouseInput)) || size > 4096)
                return;
            IntPtr buffer = Marshal.AllocHGlobal((int)size);
            try
            {
                n = NativeInput.GetRawInputData(handle, NativeInput.RID_INPUT,
                    buffer, ref size, hsize);
                if (n == uint.MaxValue || n < (uint)Marshal.SizeOf(typeof(NativeInput.RawHeader)))
                    return;
                NativeInput.RawHeader hdr = (NativeInput.RawHeader)Marshal.PtrToStructure(
                    buffer, typeof(NativeInput.RawHeader));
                if (hdr.type != 0) return; // RIM_TYPEMOUSE
                NativeInput.RawMouseInput rm = (NativeInput.RawMouseInput)Marshal.PtrToStructure(
                    buffer, typeof(NativeInput.RawMouseInput));
                _onMouse(rm.mouse);
            }
            finally { Marshal.FreeHGlobal(buffer); }
        }
        public void Dispose()
        {
            // unregister capture before destroying the sink window
            NativeInput.RawInputDevice[] d = new NativeInput.RawInputDevice[] {
                new NativeInput.RawInputDevice {usagePage=1, usage=2, flags=1, target=IntPtr.Zero}
            };
            NativeInput.RegisterRawInputDevices(d, 1,
                (uint)Marshal.SizeOf(typeof(NativeInput.RawInputDevice)));
            DestroyHandle();
        }
    }

    internal sealed class AkvmMessage
    {
        internal byte Type;
        internal byte[] Payload;
        internal AkvmMessage(byte type, byte[] payload) { Type = type; Payload = payload; }
    }

    internal sealed class AkvmSender : IDisposable
    {
        private readonly Socket _socket;
        private readonly EndPoint _endpoint;
        private readonly Queue<AkvmMessage> _pending = new Queue<AkvmMessage>();
        private readonly object _gate = new object();
        private readonly AutoResetEvent _wake = new AutoResetEvent(false);
        private readonly Thread _worker;
        private volatile bool _running = true;
        private volatile bool _active;
        private ushort _seq;
        private int _dx, _dy, _buttons, _lastSentButtons, _wheel;
        private bool _mouseDirty;
        private int _wheelSteps;
        private double _scale;
        private double _fracX, _fracY;
        private long _nextHeartbeat;
        private long _sentCount;

        internal AkvmSender(string host, int port, double mouseScale, int wheelSteps)
        {
            IPAddress address;
            if (!IPAddress.TryParse(host, out address) || address.AddressFamily != AddressFamily.InterNetwork)
                throw new ArgumentException("--host must be an IPv4 address, e.g. 192.168.1.29");
            _endpoint = new IPEndPoint(address, port);
            _socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            _scale = mouseScale;
            _wheelSteps = wheelSteps;
            _worker = new Thread(SenderLoop) { IsBackground = true, Name = "AKVM sender" };
            _worker.Start();
        }

        private void QueueUnsafe(byte type, params byte[] payload)
        {
            if (_pending.Count >= 1024)
            {
                // Safety over throughput. A full queue means remote key state is no longer trustworthy.
                _pending.Clear();
                _pending.Enqueue(new AkvmMessage(4, new byte[0])); // ALLUP
            }
            _pending.Enqueue(new AkvmMessage(type, payload));
        }
        internal void Key(byte raw, bool down)
        {
            lock (_gate)
            {
                if (!_active) return;
                QueueUnsafe(1, raw, (byte)(down ? 1 : 0));
            }
            _wake.Set();
        }
        internal void KeyPulse(byte raw)
        {
            Key(raw, true);
            Key(raw, false);
        }
        internal void Mouse(NativeInput.RawMouse mouse)
        {
            if (!_active) return;
            lock (_gate)
            {
                if (!_active) return;
                if ((mouse.flags & 1) == 0) // ignore absolute-position mice/tablets in this POC
                {
                    double xs = mouse.dx * _scale + _fracX;
                    double ys = mouse.dy * _scale + _fracY;
                    int x = (int)Math.Max(-32768, Math.Min(32767, Math.Truncate(xs)));
                    int y = (int)Math.Max(-32768, Math.Min(32767, Math.Truncate(ys)));
                    _fracX = xs - x; _fracY = ys - y;
                    _dx += x; _dy += y;
                }
                int flags = (int)(mouse.buttons & 0xFFFF);
                if ((flags & 0x0001) != 0) _buttons |= 1;
                if ((flags & 0x0002) != 0) _buttons &= ~1;
                if ((flags & 0x0004) != 0) _buttons |= 2;
                if ((flags & 0x0008) != 0) _buttons &= ~2;
                if ((flags & 0x0010) != 0) _buttons |= 4;
                if ((flags & 0x0020) != 0) _buttons &= ~4;
                if ((flags & 0x0400) != 0)
                    _wheel += unchecked((short)(mouse.buttons >> 16));
                if (_buttons != _lastSentButtons)
                {
                    // Never coalesce button edges: fast clicks must survive 20 ms mouse batching.
                    QueueUnsafe(7, 0, 0, 0, 0, (byte)_buttons);
                    _lastSentButtons = _buttons;
                }
                _mouseDirty = _dx != 0 || _dy != 0;
            }
            _wake.Set();
        }
        internal void SetActive(bool value)
        {
            lock (_gate)
            {
                if (_active == value) return;
                _active = value;
                _dx = _dy = _buttons = _lastSentButtons = _wheel = 0;
                _fracX = _fracY = 0;
                _mouseDirty = false;
                _pending.Clear();
                // Repeat ALLUP to mitigate packet loss and stuck remote keys on transitions.
                for (int i = 0; i < 4; i++) QueueUnsafe(4, new byte[0]);
                _nextHeartbeat = EnvironmentExtensions.TickCount64Safe() + 1000;
            }
            _wake.Set();
        }
        private void SendPacket(byte type, byte[] data)
        {
            byte[] packet = new byte[8 + data.Length];
            packet[0] = (byte)'A'; packet[1] = (byte)'K';
            packet[2] = (byte)'V'; packet[3] = (byte)'M';
            packet[4] = 1; packet[5] = type;
            _seq++;
            packet[6] = (byte)(_seq >> 8); packet[7] = (byte)_seq;
            Buffer.BlockCopy(data, 0, packet, 8, data.Length);
            try { _socket.SendTo(packet, _endpoint); Interlocked.Increment(ref _sentCount); }
            catch (SocketException) { /* UDP best effort; DDC/CI fail-safe remains local */ }
            catch (ObjectDisposedException) { }
        }
        private void SenderLoop()
        {
            while (_running)
            {
                _wake.WaitOne(20);
                List<AkvmMessage> batch = new List<AkvmMessage>();
                lock (_gate)
                {
                    while (_pending.Count > 0) batch.Add(_pending.Dequeue());
                    if (_active)
                    {
                        if (_mouseDirty)
                        {
                            int x = Math.Max(-32768, Math.Min(32767, _dx));
                            int y = Math.Max(-32768, Math.Min(32767, _dy));
                            _dx -= x; _dy -= y;
                            _lastSentButtons = _buttons;
                            batch.Add(new AkvmMessage(7, new byte[] {
                                (byte)(x >> 8), (byte)x, (byte)(y >> 8), (byte)y,
                                (byte)_buttons
                            }));
                            _mouseDirty = (_dx != 0 || _dy != 0);
                        }
                        int notches = Math.Max(-20, Math.Min(20, _wheel / 120));
                        _wheel -= notches * 120;
                        byte arrow = (byte)(notches > 0 ? 0x4C : 0x4D);
                        int repeats = Math.Min(60, Math.Abs(notches) * _wheelSteps);
                        for (int i = 0; i < repeats; i++)
                        {
                            batch.Add(new AkvmMessage(1, new byte[] {arrow, 1}));
                            batch.Add(new AkvmMessage(1, new byte[] {arrow, 0}));
                        }
                        if (EnvironmentExtensions.TickCount64Safe() >= _nextHeartbeat)
                        {
                            batch.Add(new AkvmMessage(5, new byte[0]));
                            _nextHeartbeat = EnvironmentExtensions.TickCount64Safe() + 1000;
                        }
                    }
                }
                foreach (AkvmMessage item in batch) SendPacket(item.Type, item.Payload);
            }
        }
        public void Dispose()
        {
            SetActive(false);
            // Allow repeated ALLUP packets to leave the socket before shutdown.
            _wake.Set(); Thread.Sleep(120);
            _running = false;
            _wake.Set();
            _worker.Join(1000);
            _socket.Dispose(); _wake.Dispose();
        }
        internal long SentCount { get { return Interlocked.Read(ref _sentCount); } }
    }

    internal static class EnvironmentExtensions
    {
        // Environment.TickCount is available in .NET Framework 4.x; represent it as unsigned
        // elapsed ticks to avoid the normal 24.9-day signed rollover.
        internal static long TickCount64Safe() { return unchecked((uint)System.Environment.TickCount); }
    }

    internal sealed class Controller : IDisposable
    {
        private readonly AkvmSender _sender;
        private readonly bool _capture;
        private readonly int _monitorIndex, _target, _windowsSource, _interval;
        private readonly Thread _poller;
        private System.Windows.Forms.Timer _watchdog;
        private long _lastValidPollTick;
        private InputWindow _sink;
        private NativeInput.HookProc _keyboardProc, _mouseProc;
        private IntPtr _keyboardHook, _mouseHook;
        private volatile bool _active;
        private volatile bool _quarantine; // local input suppressed; no Amiga delivery
        private volatile bool _manualPause;
        private volatile bool _running = true;
        private readonly object _keyGate = new object();
        private readonly HashSet<int> _heldKeys = new HashSet<int>();
        private readonly HashSet<int> _capsOwners = new HashSet<int>();
        private bool _capsOn, _physicalShift, _synthShift;
        private bool _ctrl, _alt, _shift;
        private bool _leftShiftDown, _rightShiftDown;

        internal Controller(string host, int port, bool capture, int monitor, int target,
            int windowsSource, int interval, double scale, int wheel)
        {
            _capture = capture; _monitorIndex = monitor;
            _target = target; _windowsSource = windowsSource; _interval = interval;
            _sender = new AkvmSender(host, port, scale, wheel);
            _poller = new Thread(PollMonitor) { IsBackground = true, Name = "DDC/CI poller" };
        }
        internal void Run()
        {
            _sink = new InputWindow(_sender.Mouse);
            if (_capture)
            {
                // Fail closed from startup: no local input until detected Windows source is verified twice.
                _quarantine = true;
                _keyboardProc = KeyboardHook;
                _mouseProc = MouseHook;
                IntPtr module = NativeInput.GetModuleHandle(null);
                _keyboardHook = NativeInput.SetWindowsHookEx(NativeInput.WH_KEYBOARD_LL, _keyboardProc, module, 0);
                _mouseHook = NativeInput.SetWindowsHookEx(NativeInput.WH_MOUSE_LL, _mouseProc, module, 0);
                if (_keyboardHook == IntPtr.Zero || _mouseHook == IntPtr.Zero)
                    throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(),
                        "Unable to install low-level hooks");
            }
            Interlocked.Exchange(ref _lastValidPollTick, EnvironmentExtensions.TickCount64Safe());
            _watchdog = new System.Windows.Forms.Timer();
            _watchdog.Interval = 250;
            _watchdog.Tick += delegate(object sender, EventArgs args)
            {
                long now = EnvironmentExtensions.TickCount64Safe();
                long then = Interlocked.Read(ref _lastValidPollTick);
                // Also guard the Windows-source state: a DDC read can hang
                // while the display is switching, before UNKNOWN is returned.
                if (_capture && !_quarantine && !_manualPause &&
                    unchecked((uint)(now - then)) >= (uint)Math.Max(1500, 3 * _interval))
                    SetQuarantine("DDC/CI watchdog: stale source reading");
            };
            _watchdog.Start();
            _poller.Start();
            Console.WriteLine(_capture ? "FAIL-CLOSED CAPTURE ARMED: Windows remains blocked until source " +
                _windowsSource + " is confirmed twice." :
                "OBSERVE ONLY. Add --capture to enable mouse/keyboard forwarding.");
            Console.WriteLine("Emergency manual override: Ctrl+Alt+Shift+F12.");
            Console.WriteLine("Close this console to stop the program.");
            Application.Run(); // Low-level hooks MUST have a message loop.
        }
        internal void Stop()
        {
            _running = false;
            SetActive(false, "shutdown");
            if (_sink != null && _sink.Handle != IntPtr.Zero)
                NativeInput.PostMessage(_sink.Handle, NativeInput.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
        }
        private void ResetHeldKeys()
        {
            _heldKeys.Clear(); _capsOwners.Clear();
            _capsOn = _physicalShift = _synthShift = false;
            _ctrl = _alt = _shift = false;
            _leftShiftDown = _rightShiftDown = false;
        }
        // FAIL-CLOSED: on any uncertain DDC/CI state, swallow local inputs and send
        // nothing to Amiga. Do NOT give Windows back control on a monitor timeout.
        // Only 2 confirmed readings of --windows-source, or the emergency hotkey,
        // can restore Windows input. Observe-only mode never suppresses input.
        private void SetQuarantine(string why)
        {
            if (!_capture || _manualPause) return;
            lock (_keyGate)
            {
                if (_manualPause || (_quarantine && !_active)) return;
                _quarantine = true; // block input BEFORE disabling the remote sender
                _active = false;
                _sender.SetActive(false); // ALLUP to the Amiga
                ResetHeldKeys();
            }
            Console.WriteLine("{0:HH:mm:ss.fff} INPUT QUARANTINE (both hosts blocked): {1}",
                DateTime.Now, why);
        }
        private void SetActive(bool value, string why)
        {
            lock (_keyGate)
            {
                if (value)
                {
                    if (_active && !_quarantine) return;
                    // Prevent a transient interval where local and remote both get input.
                    if (_capture) _quarantine = true;
                    _sender.SetActive(_capture);
                    ResetHeldKeys();
                    _active = true;
                    _quarantine = false;
                }
                else
                {
                    if (!_active && !_quarantine) return;
                    _active = false;
                    _sender.SetActive(false);
                    ResetHeldKeys();
                    _quarantine = false; // explicit Windows confirmation / manual release
                }
            }
            Console.WriteLine("{0:HH:mm:ss.fff} {1} ({2})", DateTime.Now,
                value ? (_capture ? "AMIGA INPUT ACTIVE; WINDOWS SUPPRESSED" :
                    "AMIGA SOURCE DETECTED") : "WINDOWS INPUT RESTORED", why);
        }
        private void PollMonitor()
        {
            List<MonitorHandle> monitors = null;
            try
            {
                monitors = MonitorApi.Enumerate();
                if (_monitorIndex >= monitors.Count)
                    throw new ArgumentException("Invalid monitor index; run HDMIKVM.exe --list first");
                MonitorHandle monitor = monitors[_monitorIndex];
                Console.WriteLine("Monitor: {0} / {1} Windows={2}; Amiga target={3}", monitor.Device,
                    monitor.Description, _windowsSource, _target);
                int confirmedTarget = 0, confirmedOther = 0, failures = 0;
                int? previous = null;
                bool unknownLogged = false;
                while (_running)
                {
                    ReadResult result = MonitorApi.ReadInput(monitor);
                    long now = EnvironmentExtensions.TickCount64Safe();
                    if (result.Success)
                    {
                        Interlocked.Exchange(ref _lastValidPollTick, now);
                        failures = 0;
                        if (!previous.HasValue || previous.Value != (int)result.Value || unknownLogged)
                            Console.WriteLine("{0:HH:mm:ss.fff} VCP 0x60={1}", DateTime.Now, result.Value);
                        unknownLogged = false;
                        previous = (int)result.Value;
                        if ((int)result.Value == _target)
                        {
                            confirmedTarget++; confirmedOther = 0;
                            if (confirmedTarget >= 2 && !_manualPause)
                                SetActive(true, "two confirmed Amiga readings");
                            else
                                SetQuarantine("awaiting Amiga confirmation");
                        }
                        else if ((int)result.Value == _windowsSource)
                        {
                            confirmedOther++; confirmedTarget = 0;
                            if (confirmedOther >= 2)
                            {
                                SetActive(false, "two confirmed Windows readings");
                                _manualPause = false; // re-arm after visiting Windows source
                            }
                            else
                                SetQuarantine("awaiting Windows confirmation");
                        }
                        else
                        {
                            confirmedTarget = confirmedOther = 0;
                            SetQuarantine("unconfigured display source " + result.Value);
                        }
                    }
                    else
                    {
                        confirmedTarget = confirmedOther = 0;
                        failures++;
                        SetQuarantine("DDC/CI UNKNOWN");
                        if (!unknownLogged)
                        {
                            Console.WriteLine("{0:HH:mm:ss.fff} VCP UNKNOWN (error {1})", DateTime.Now,
                                result.Win32Error);
                            unknownLogged = true;
                        }
                        // UNKNOWN is NOT proof that Windows is visible. Fail closed.
                        // Windows input stays suppressed until its VCP value is verified.
                        if (failures >= 10)
                        {
                            failures = 0;
                            try
                            {
                                if (MonitorApi.TryReacquire(ref monitors, ref monitor))
                                    Console.WriteLine("DDC/CI monitor handle reacquired");
                            }
                            catch (Exception ex) { Console.WriteLine("Monitor reacquire: " + ex.Message); }
                        }
                    }
                    Thread.Sleep(_interval);
                }
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("DDC/CI error: " + ex.Message);
                SetQuarantine("monitor unavailable");
                // Keep hooks and manual emergency release functional. The main
                // program remains active; never silently re-enable Windows here.
                _running = false;
            }
            finally { if (monitors != null) MonitorApi.Release(monitors); }
        }
        private static readonly Dictionary<int, byte> Scan = BuildScanMap();
        private static Dictionary<int, byte> BuildScanMap()
        {
            // PC Set-1 physical scancodes to Amiga RAWKEY positions.
            var d = new Dictionary<int, byte>();
            int[] codes = { 0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B };
            for (int i = 0; i < 10; i++) d[codes[i]] = (byte)(i+1);
            for (int i=0; i<10; i++) d[0x10+i] = (byte)(0x10+i); // Q..P
            for (int i=0; i<9; i++) d[0x1E+i] = (byte)(0x20+i); // A..L
            for (int i=0; i<10; i++) d[0x2C+i] = (byte)(0x31+i); // Z..slash
            d[0x01]=0x45; d[0x0C]=0x0B; d[0x0D]=0x0C; d[0x0E]=0x41;
            d[0x0F]=0x42; d[0x1A]=0x1A; d[0x1B]=0x1B; d[0x1C]=0x44;
            d[0x1D]=0x63; d[0x27]=0x29; d[0x28]=0x2A; d[0x29]=0x00;
            d[0x2A]=0x60; d[0x2B]=0x0D; d[0x36]=0x61;
            d[0x38]=0x64; // Left Alt / Option -> Amiga Left Alt (restored)
            d[0x39]=0x40; d[0x3A]=0x62; d[0x56]=0x30;
            for (int i=0; i<10; i++) d[0x3B+i] = (byte)(0x50+i); // F1..F10
            d[0x100|0x1D]=0x63; // Right Ctrl, receiver has one Ctrl
            d[0x100|0x38]=0x65; // Right Alt
            d[0x100|0x48]=0x4C; d[0x100|0x50]=0x4D; // Up, Down
            d[0x100|0x4D]=0x4E; d[0x100|0x4B]=0x4F; // Right, Left
            d[0x100|0x53]=0x46; // Delete
            d[0x100|0x5B]=0x66; // Left Win / Mac Command -> Left Amiga
            d[0x100|0x5C]=0x67; // Right Win -> Right Amiga (FIX3 behavior preserved)
            d[0x100|0x5D]=0x67; // Application/Menu key -> Right Amiga (pictured keyboard)
            return d;
        }
        // Windows may mark VK_RSHIFT (scan 0x36) LLKHF_EXTENDED (E0).
        // That must NOT turn 0x36 into 0x136: the AKVM map uses 0x36 ->
        // Amiga RAW_RSHIFT 0x61. The same normalization covers odd HID
        // drivers that emit a zero scan code but a side-specific VK.
        internal static int NormalizeKeyboardScan(uint vk, uint scanCode, uint flags)
        {
            int scan = (int)(scanCode & 0xFF);
            if (vk == NativeInput.VK_RSHIFT || scan == 0x36) return 0x36;
            if (vk == NativeInput.VK_LSHIFT || scan == 0x2A) return 0x2A;
            // Windows/Command keys are E0-prefixed. Some keyboards (notably
            // Apple USB keyboards) do not report the extended flag reliably.
            if (vk == NativeInput.VK_LWIN) return 0x15B;
            if (vk == NativeInput.VK_RWIN) return 0x15C;
            // The dedicated Application/Menu key has VK_APPS (E0 5D).
            // Normalize by VK even if a keyboard omits LLKHF_EXTENDED.
            if (vk == NativeInput.VK_APPS) return 0x15D;
            // Alt/Option stays Alt; distinguish left/right even with inconsistent E0.
            if (vk == NativeInput.VK_LMENU) return 0x38;
            if (vk == NativeInput.VK_RMENU) return 0x138;
            if ((flags & NativeInput.LLKHF_EXTENDED) != 0) scan |= 0x100;
            return scan;
        }
        internal static bool TestKeyboardMap()
        {
            bool ok = NormalizeKeyboardScan(0x10, 0x36, 0x00) == 0x36 &&
                NormalizeKeyboardScan(0x10, 0x36, NativeInput.LLKHF_EXTENDED) == 0x36 &&
                NormalizeKeyboardScan(NativeInput.VK_RSHIFT, 0, NativeInput.LLKHF_EXTENDED) == 0x36 &&
                NormalizeKeyboardScan(NativeInput.VK_LSHIFT, 0, NativeInput.LLKHF_EXTENDED) == 0x2A &&
                NormalizeKeyboardScan(0xA3, 0x1D, NativeInput.LLKHF_EXTENDED) == 0x11D &&
                NormalizeKeyboardScan(0x26, 0x48, NativeInput.LLKHF_EXTENDED) == 0x148 &&
                NormalizeKeyboardScan(NativeInput.VK_LWIN, 0x5B, 0) == 0x15B &&
                NormalizeKeyboardScan(NativeInput.VK_LWIN, 0x5B, NativeInput.LLKHF_EXTENDED) == 0x15B &&
                NormalizeKeyboardScan(NativeInput.VK_RWIN, 0, 0) == 0x15C &&
                NormalizeKeyboardScan(NativeInput.VK_APPS, 0x5D, 0) == 0x15D &&
                NormalizeKeyboardScan(NativeInput.VK_APPS, 0x5D, NativeInput.LLKHF_EXTENDED) == 0x15D &&
                NormalizeKeyboardScan(NativeInput.VK_LMENU, 0x38, 0) == 0x38 &&
                NormalizeKeyboardScan(NativeInput.VK_LMENU, 0, NativeInput.LLKHF_EXTENDED) == 0x38 &&
                NormalizeKeyboardScan(NativeInput.VK_RMENU, 0x38, 0) == 0x138 &&
                Scan[0x36] == 0x61 && Scan[0x2A] == 0x60 &&
                Scan[0x15B] == 0x66 && Scan[0x38] == 0x64 &&
                Scan[0x15D] == 0x67 && Scan[0x15C] == 0x67 && Scan[0x138] == 0x65;
            Console.WriteLine(ok ? "Keyboard map self-test PASS (RSHIFT; LWIN->LAMIGA; MENU->RAMIGA; LALT->LALT)" :
                "Keyboard map self-test FAIL");
            return ok;
        }
        private IntPtr KeyboardHook(int code, IntPtr wp, IntPtr lp)
        {
            if (code < 0 || !_capture || (!_active && !_quarantine))
                return NativeInput.CallNextHookEx(_keyboardHook, code, wp, lp);
            lock (_keyGate)
            {
            if (!_active && !_quarantine)
                return NativeInput.CallNextHookEx(_keyboardHook, code, wp, lp);
            int message = wp.ToInt32();
            if (message != NativeInput.WM_KEYDOWN && message != NativeInput.WM_KEYUP &&
                message != NativeInput.WM_SYSKEYDOWN && message != NativeInput.WM_SYSKEYUP)
                return NativeInput.CallNextHookEx(_keyboardHook, code, wp, lp);
            var k = (NativeInput.KbdLlData)Marshal.PtrToStructure(lp, typeof(NativeInput.KbdLlData));
            if ((k.flags & NativeInput.LLKHF_INJECTED) != 0)
                return NativeInput.CallNextHookEx(_keyboardHook, code, wp, lp);
            bool down = message == NativeInput.WM_KEYDOWN || message == NativeInput.WM_SYSKEYDOWN;
            int scan = NormalizeKeyboardScan(k.vkCode, k.scanCode, k.flags);
            int modifierScan = scan & 0xFF;
            if (modifierScan == 0x1D) _ctrl = down;
            if (modifierScan == 0x38) _alt = down;
            if (scan == 0x2A) _leftShiftDown = down;
            if (scan == 0x36) _rightShiftDown = down;
            _shift = _leftShiftDown || _rightShiftDown;
            if ((int)k.vkCode == NativeInput.VK_F12 && down && _ctrl && _alt && _shift)
            {
                _manualPause = true;
                SetActive(false, "EMERGENCY HOTKEY");
                Console.WriteLine("Manual pause: switch monitor away from target to re-arm.");
                return new IntPtr(1);
            }
            // In transition, suppress all physical keys without forwarding to Amiga.
            if (_quarantine || !_active) return new IntPtr(1);
            byte raw;
            if (!Scan.TryGetValue(scan, out raw))
                return new IntPtr(1); // Unknown keys are suppressed while remote controls are active.
            if (scan == 0x3A) // Caps Lock, handled locally rather than through Amiga keyboard LED state
            {
                if (down && !_heldKeys.Contains(scan)) _capsOn = !_capsOn;
                if (down) _heldKeys.Add(scan); else _heldKeys.Remove(scan);
                return new IntPtr(1);
            }
            bool wasHeld = _heldKeys.Contains(scan);
            if (down) _heldKeys.Add(scan); else _heldKeys.Remove(scan);
            // Preserve Shift when the other physical Shift is released.
            _physicalShift = _heldKeys.Contains(0x2A) || _heldKeys.Contains(0x36);
            // A repeating key-down is sent through: receiver explicitly supports autorepeat.
            bool letter = (scan >= 0x10 && scan <= 0x19) ||
                (scan >= 0x1E && scan <= 0x26) || (scan >= 0x2C && scan <= 0x32);
            if (down && !wasHeld && letter && _capsOn && !_physicalShift)
            {
                if (!_synthShift) { _sender.Key(0x60, true); _synthShift = true; }
                _capsOwners.Add(scan);
            }
            if (!down && !wasHeld) return new IntPtr(1);
            if (wasHeld && down && (raw >= 0x60 && raw <= 0x67)) return new IntPtr(1);
            // Menu and Right Win both map to RAWKEY 0x67. Send a press
            // only for the first physical key down, release only for the last
            // key up, so simultaneous use cannot leave Right Amiga stuck.
            if (raw == 0x67 && (scan == 0x15D || scan == 0x15C))
            {
                int otherScan = scan == 0x15D ? 0x15C : 0x15D;
                if (_heldKeys.Contains(otherScan)) return new IntPtr(1);
            }
            _sender.Key(raw, down);
            if (!down && _capsOwners.Remove(scan) && _capsOwners.Count == 0 && _synthShift)
            {
                _sender.Key(0x60, false); _synthShift = false;
            }
            return new IntPtr(1);
            }
        }
        private IntPtr MouseHook(int code, IntPtr wp, IntPtr lp)
        {
            if (code >= 0 && _capture && (_active || _quarantine))
                return new IntPtr(1); // Suppress local Windows mouse messages.
            return NativeInput.CallNextHookEx(_mouseHook, code, wp, lp);
        }
        public void Dispose()
        {
            _running = false;
            SetActive(false, "exit");
            if (_watchdog != null) { _watchdog.Stop(); _watchdog.Dispose(); }
            if (_keyboardHook != IntPtr.Zero) NativeInput.UnhookWindowsHookEx(_keyboardHook);
            if (_mouseHook != IntPtr.Zero) NativeInput.UnhookWindowsHookEx(_mouseHook);
            if (_sink != null) _sink.Dispose();
            _sender.Dispose();
        }
    }

    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            bool list=false, capture=false;
            int monitor=0, target=17, windowsSource=16, interval=1000, port=6800, wheel=3;
            bool autoWindowsSource=false;
            string host=null;
            double scale=1;
            try
            {
                for (int i=0; i<args.Length; i++)
                {
                    string a=args[i];
                    if (a=="--help" || a=="/?") { Usage(); return 0; }
                    if (a=="--selftest-keys") return Controller.TestKeyboardMap() ? 0 : 1;
                    if (a=="--list") { list=true; continue; }
                    if (a=="--capture") { capture=true; continue; }
                    if (++i>=args.Length) throw new ArgumentException("Missing value after " + a);
                    string val=args[i];
                    if (a=="--host") host=val;
                    else if (a=="--port") port=int.Parse(val);
                    else if (a=="--monitor") monitor=int.Parse(val);
                    else if (a=="--target") target=val.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ?
                        Convert.ToInt32(val.Substring(2),16) : int.Parse(val);
                    else if (a=="--windows-source")
                    {
                        autoWindowsSource=String.Equals(val, "auto", StringComparison.OrdinalIgnoreCase);
                        if (!autoWindowsSource)
                            windowsSource=val.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ?
                                Convert.ToInt32(val.Substring(2),16) : int.Parse(val);
                    }
                    else if (a=="--interval") interval=int.Parse(val);
                    else if (a=="--mouse-scale") scale=double.Parse(val,CultureInfo.InvariantCulture);
                    else if (a=="--wheel-steps") wheel=int.Parse(val);
                    else throw new ArgumentException("Unknown argument: " + a);
                }
                if (list)
                {
                    List<MonitorHandle> monitors=MonitorApi.Enumerate();
                    try
                    {
                        for(int i=0;i<monitors.Count;i++)
                        {
                            ReadResult result=MonitorApi.ReadInput(monitors[i]);
                            Console.WriteLine("[{0}] {1} / {2} - {3}", i,monitors[i].Device,
                                monitors[i].Description, result.Success ?
                                result.Value.ToString() : "UNKNOWN");
                        }
                    }
                    finally { MonitorApi.Release(monitors); }
                    return 0;
                }
                if (String.IsNullOrEmpty(host)) throw new ArgumentException("--host AMIGA_IPV4 required");
                // The polling interval is capped at 2000 ms even in watch-only mode.
                // Longer intervals increase the blind window before HDMI changes are detected.
                if (interval < 250 || interval > 2000)
                    throw new ArgumentException("--interval must be between 250 and 2000 ms");
                if (monitor<0 || target<0 || target>255 ||
                    (!autoWindowsSource && (windowsSource<0 || windowsSource>255)) ||
                    port<1 || port>65535 ||
                    scale<=0 || scale>10 || wheel<0 || wheel>20)
                    throw new ArgumentException("Invalid monitor/target/interval/port/scale/wheel argument");
                // Resolve before opening the UDP sender or installing hooks.
                // If DDC/CI is UNKNOWN at launch, do not guess the Windows source.
                if (autoWindowsSource)
                    windowsSource = DetectStartupWindowsSource(monitor, target, interval);
                if (target == windowsSource)
                    throw new ArgumentException("Amiga source equals the current Windows source (" +
                        windowsSource + "). Start while Windows is displayed and choose a different Amiga source.");
                Console.WriteLine("HDMIKVM POC2 FIX6 / AKVM/1 UDP {0}:{1}; Windows={2}, Amiga={3}",
                    host,port,windowsSource,target);
                using (Controller controller = new Controller(host,port,capture,monitor,target,windowsSource,interval,scale,wheel))
                {
                    Console.CancelKeyPress += delegate(object sender, ConsoleCancelEventArgs e)
                    {
                        e.Cancel=true;
                        controller.Stop();
                    };
                    controller.Run();
                }
                return 0;
            }
            catch(Exception ex) { Console.Error.WriteLine("ERROR: " + ex); return 1; }
        }
        // The selected input at startup is, by definition, the Windows source.
        // Require two consecutive valid identical readings before arming capture.
        // An UNKNOWN or changing input cannot be used as a routing baseline.
        private static int DetectStartupWindowsSource(int monitorIndex, int amigaSource, int interval)
        {
            List<MonitorHandle> monitors = MonitorApi.Enumerate();
            try
            {
                if (monitorIndex >= monitors.Count)
                    throw new ArgumentException("Invalid monitor index; run HDMIKVM.exe --list");
                MonitorHandle monitor = monitors[monitorIndex];
                Console.WriteLine("Detecting CURRENT Windows input: {0} / {1}",
                    monitor.Device, monitor.Description);
                int previous = -1, consecutive = 0;
                for (int attempt = 0; attempt < 12; attempt++)
                {
                    ReadResult result = MonitorApi.ReadInput(monitor);
                    if (result.Success && result.Value > 0 && result.Value <= 255)
                    {
                        int source = (int)result.Value;
                        Console.WriteLine("  Startup VCP 0x60 = {0}", source);
                        if (source == amigaSource)
                            throw new ArgumentException("Current input " + source +
                                " matches the Amiga source. Select the Windows input first.");
                        consecutive = source == previous ? consecutive + 1 : 1;
                        previous = source;
                        if (consecutive >= 2)
                        {
                            Console.WriteLine("  Windows input automatically set to {0}", source);
                            return source;
                        }
                    }
                    else
                    {
                        Console.WriteLine("  Startup VCP UNKNOWN (read {0}/12)", attempt + 1);
                        previous = -1;
                        consecutive = 0;
                    }
                    Thread.Sleep(interval);
                }
                throw new InvalidOperationException("Unable to confirm a stable Windows HDMI input. " +
                    "No keyboard/mouse capture started. Run again while Windows is displayed.");
            }
            finally { MonitorApi.Release(monitors); }
        }

        private static void Usage()
        {
            Console.WriteLine("HDMIKVM POC2 FIX6 - Windows HDMI auto-KVM sender for l3-netkeys v1.1");
            Console.WriteLine("  HDMIKVM.exe --list");
            Console.WriteLine("  HDMIKVM.exe --selftest-keys");
            Console.WriteLine("  HDMIKVM.exe --host 192.168.1.29 [--monitor 0] [--target 17]");
            Console.WriteLine("             [--windows-source 16|auto]");
            Console.WriteLine("             [--interval 1000] [--port 6800] [--mouse-scale 1]");
            Console.WriteLine("             [--wheel-steps 3] [--capture]");
            Console.WriteLine("--interval range: 250..2000 ms (default: 1000 ms).");
            Console.WriteLine("KVM.cmd IP AMIGA_SOURCE detects Windows source at startup (auto). ");
            Console.WriteLine("Safe default: without --capture, SOURCE DETECTION ONLY.");
            Console.WriteLine("Unknown/unconfirmed HDMI source blocks BOTH hosts in --capture mode.");
            Console.WriteLine("Ctrl+Alt+Shift+F12 always restores Windows manually.");
        }
    }
}
