@echo off
if not exist "%~dp0HDMIKVM.exe" call "%~dp0BUILD.cmd" || exit /b 1
"%~dp0HDMIKVM.exe" --list
pause
