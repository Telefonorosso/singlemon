// HDMIInputProbe - Windows DDC/CI input source reader (POC1)
// Copyright (c) 2026. MIT licensed. Windows 10/11, .NET Framework 4.x.
// Read-only: VCP 0x60 is queried; the tool never changes monitor settings.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace HDMIInputProbe
{
    internal static class Win32
    {
        [StructLayout(LayoutKind.Sequential)]
        internal struct Rect
        {
            public int Left, Top, Right, Bottom;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct MonitorInfoEx
        {
            public uint cbSize;
            public Rect rcMonitor;
            public Rect rcWork;
            public uint dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string szDevice;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct PhysicalMonitor
        {
            public IntPtr hPhysicalMonitor;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string szPhysicalMonitorDescription;
        }

        internal delegate bool MonitorEnumProc(IntPtr hMonitor, IntPtr hdcMonitor,
                                                IntPtr lprcMonitor, IntPtr dwData);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr rect,
                                                        MonitorEnumProc callback, IntPtr data);

        [DllImport("user32.dll", EntryPoint = "GetMonitorInfoW", CharSet = CharSet.Unicode,
                   SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfoEx info);

        [DllImport("dxva2.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetNumberOfPhysicalMonitorsFromHMONITOR(
            IntPtr monitor, out uint count);

        [DllImport("dxva2.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetPhysicalMonitorsFromHMONITOR(
            IntPtr monitor, uint count, [Out] PhysicalMonitor[] physicalMonitors);

        [DllImport("dxva2.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool DestroyPhysicalMonitor(IntPtr physicalMonitor);

        [DllImport("dxva2.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetVCPFeatureAndVCPFeatureReply(
            IntPtr physicalMonitor, byte vcpCode, IntPtr vcpCodeType,
            out uint currentValue, out uint maximumValue);
    }

    internal sealed class MonitorHandle
    {
        internal IntPtr Handle;
        internal string Device;
        internal string Description;
        internal bool Primary;
    }

    internal sealed class ReadResult
    {
        internal bool Success;
        internal uint Value;
        internal int Win32Error;
    }

    internal static class MonitorApi
    {
        internal static List<MonitorHandle> Enumerate()
        {
            List<MonitorHandle> items = new List<MonitorHandle>();
            Win32.MonitorEnumProc callback = delegate(IntPtr display, IntPtr hdc,
                                                      IntPtr rect, IntPtr data)
            {
                Win32.MonitorInfoEx info = new Win32.MonitorInfoEx();
                info.cbSize = (uint)Marshal.SizeOf(typeof(Win32.MonitorInfoEx));
                string device = "(unknown display)";
                bool primary = false;
                if (Win32.GetMonitorInfo(display, ref info))
                {
                    device = info.szDevice;
                    primary = (info.dwFlags & 1) != 0;
                }

                uint count;
                if (!Win32.GetNumberOfPhysicalMonitorsFromHMONITOR(display, out count)
                    || count == 0 || count > 64)
                    return true; // Some virtual displays have no DDC/CI monitor.

                Win32.PhysicalMonitor[] physical = new Win32.PhysicalMonitor[(int)count];
                if (!Win32.GetPhysicalMonitorsFromHMONITOR(display, count, physical))
                    return true;

                for (int i = 0; i < physical.Length; i++)
                {
                    items.Add(new MonitorHandle {
                        Handle = physical[i].hPhysicalMonitor,
                        Device = device,
                        Description = physical[i].szPhysicalMonitorDescription,
                        Primary = primary
                    });
                }
                return true;
            };

            if (!Win32.EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, callback, IntPtr.Zero))
                throw new InvalidOperationException("EnumDisplayMonitors failed: " +
                                                    Marshal.GetLastWin32Error());
            // Keep callback alive for the duration of the native enumeration.
            GC.KeepAlive(callback);
            return items;
        }

        internal static ReadResult ReadInput(MonitorHandle monitor)
        {
            uint current, maximum;
            bool ok = Win32.GetVCPFeatureAndVCPFeatureReply(
                monitor.Handle, 0x60, IntPtr.Zero, out current, out maximum);
            int error = ok ? 0 : Marshal.GetLastWin32Error();
            return new ReadResult { Success = ok, Value = current, Win32Error = error };
        }

        // Windows can invalidate DDC/CI monitor handles during input switches.
        // Reacquire by adapter + description, never silently bind to a different screen.
        internal static bool TryReacquire(ref List<MonitorHandle> monitors,
                                          ref MonitorHandle selected)
        {
            List<MonitorHandle> fresh = Enumerate();
            int found = -1;
            int matches = 0;
            for (int i = 0; i < fresh.Count; i++)
            {
                if (String.Equals(fresh[i].Device, selected.Device,
                                  StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(fresh[i].Description, selected.Description,
                                  StringComparison.Ordinal))
                {
                    found = i;
                    matches++;
                }
            }
            if (matches != 1)
            {
                Release(fresh);
                return false; // Ambiguous/disconnected monitor: preserve the old handle.
            }

            List<MonitorHandle> old = monitors;
            monitors = fresh;
            selected = fresh[found];
            Release(old);
            return true;
        }

        internal static void Release(IEnumerable<MonitorHandle> monitors)
        {
            foreach (MonitorHandle monitor in monitors)
            {
                if (monitor.Handle != IntPtr.Zero)
                    Win32.DestroyPhysicalMonitor(monitor.Handle);
                monitor.Handle = IntPtr.Zero;
            }
        }
    }

}
