@echo off
setlocal
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo ERROR: .NET Framework v4 csc.exe is unavailable.
  exit /b 1
)
"%CSC%" /nologo /optimize+ /target:exe /platform:anycpu /out:"%~dp0HDMIKVM.exe" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "%~dp0MonitorApi.cs" "%~dp0HDMIKVM.cs"
if errorlevel 1 exit /b 1
echo Built: "%~dp0HDMIKVM.exe"
exit /b 0
