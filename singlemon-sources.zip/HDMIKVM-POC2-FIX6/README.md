# HDMIKVM POC2 FIX6 — 1000 ms default poll / 2000 ms maximum

**Change from FIX5:** default `--interval` is now **1000 ms** (was 500 ms); valid range is **250–2000 ms** (previously 250–10000 without capture, 250–1000 with capture). This maximum applies in both watch and capture modes. `KVM.cmd` and `WATCH.cmd` no longer force `--interval 500`, so they use the new executable default. The initial source auto-detection also uses the configured interval instead of a hardcoded 500 ms. No changes to the keyboard mapping, mouse forwarding, network protocol, HDMI switching state machine, watchdog formula, or AmigaOS receiver.

**Usage:** `KVM.cmd AMIGA_IP AMIGA_HDMI_SOURCE` still takes exactly two arguments and **does not recompile**. For an explicit polling interval, invoke `HDMIKVM.exe` with `--interval N`; values over 2000 are rejected. A 2000 ms interval allows a longer delay before detecting an HDMI switch, so retain the 1000 ms default unless needed.

**Status:** based on FIX5 source; FIX6 has not yet been compiled or hardware-tested on Windows. Preserve your working executable for rollback.

---

# HDMIKVM POC2 FIX5 — Menu key as Right Amiga (pictured keyboard)

**Baseline:** FIX3 hardware-validated. FIX5 is awaiting a Windows hardware test. All AmigaOS files remain unchanged, as do monitor switching, networking, Shift fix and the emergency shortcut.

## Keyboard layout matching the photo

| Physical PC key | Amiga key | RAWKEY |
| --- | --- | --- |
| **Left Windows** (Windows logo, left of space) | **Left Amiga** | `0x66` |
| **Application/Menu** (menu icon, right of space, between AltGr and Ctrl) | **Right Amiga** | `0x67` |
| Left Alt | Left Alt | `0x64` |
| Right Alt / AltGr | Right Alt | `0x65` |
| Right Windows (if present) | Right Amiga | `0x67` (preserved) |

The Application/Menu key is **Windows VK_APPS `0x5D`**, generally scan code **E0 5D**. This is **not** the left Alt/Option key mapped incorrectly in FIX4. Normalization accepts the Menu virtual-key code even when a keyboard omits the extended flag. If Menu and Right Windows are held simultaneously, a single Right Amiga state is maintained until both are released.

The emergency shortcut **Ctrl+Alt+Shift+F12** is unchanged, and the left physical Alt still participates in it. The `UNKNOWN` input quarantine is unchanged. Windows receives the original physical keys when KVM forwarding is off.

## Build and test

Extract FIX5 to a new folder. From a Windows Command Prompt:

```bat
BUILD.cmd
SELFTEST.cmd
KVM.cmd 192.168.1.29 17
```

`SELFTEST.cmd` must report `Keyboard map self-test PASS (RSHIFT; LWIN->LAMIGA; MENU->RAMIGA; LALT->LALT)`.

**Build once after extracting FIX5:** `KVM.cmd` launches the EXE directly without recompiling. Confirm the actual Menu key works as Right Amiga in AmigaOS, and Left Alt still acts as Left Alt. The `amiga-original/` receiver and UDP AKVM/1 protocol are untouched.

## FIX3: two-argument KVM.cmd and automatic Windows HDMI source

Start **while Windows is visible on the monitor**, then from Windows Command Prompt run:

```bat
KVM.cmd 192.168.1.29 17
```

These are **exactly two mandatory arguments**:

1. `192.168.1.29`: Amiga IPv4 address (replace with yours).
2. `17`: Amiga HDMI input source (`0x11` hexadecimal also accepted).

`KVM.cmd` rejects missing or extra arguments with usage text. It no longer prompts
for an IP or assumes Windows is source `16`.

At launch it runs `HDMIKVM.exe --windows-source auto`: DDC/CI VCP `0x60` is
read until **two consecutive valid, identical** input values are received.
That current value is defined as the **Windows HDMI source** for this session.
If the reading stays UNKNOWN or keeps changing for 12 attempts, or equals the
specified Amiga source, startup **fails without installing any input hooks**.
Do not change inputs while it is discovering the startup source.

For example, the resulting log might be:

```text
Detecting CURRENT Windows input: ...
  Startup VCP 0x60 = 16
  Startup VCP 0x60 = 16
  Windows input automatically set to 16
HDMIKVM POC2 FIX5 / AKVM/1 UDP 192.168.1.29:6800; Windows=16, Amiga=17
```

The original proven fail-closed logic is preserved thereafter: during `UNKNOWN`
local input is quarantined; two confirmed Windows-source readings restore
Windows; two confirmed Amiga-source readings activate forwarding; the emergency
hotkey `Ctrl+Alt+Shift+F12` manually restores Windows input.

`KVM.cmd` **does not compile** on startup. Run `BUILD.cmd` explicitly once after updating.
Do not reuse an old FIX3 `.exe` with this new `KVM.cmd`, or you will miss the mapping change.

## FIX2: right Shift recognition (Windows-only)

After the first real-world POC2 FIX1 test, right Shift was reported unreliable
while working in AmigaOS. The previous hook did this:

```
scan = scanCode & 0xFF;
if (flags & LLKHF_EXTENDED) scan |= 0x100;
```

Some Windows keyboard drivers expose the right Shift scancode `0x36` with the
`LLKHF_EXTENDED` flag. This made it `0x136`, which was not in the map, so the
hook blocked the key locally but did not forward it remotely. FIX2 normalizes
both Shift keys based on their virtual-key codes (`VK_LSHIFT` / `VK_RSHIFT`)
or scancode **before** applying the E0 bit. Right Shift now maps unconditionally
to Amiga RAWKEY `0x61` and left Shift to `0x60`. Unrelated extended keys
(Right Ctrl, Right Alt, arrow keys, etc.) keep their original mappings.

FIX2 also tracks both physical Shift keys independently, so releasing one
while holding the other does not incorrectly clear Shift state. No AKVM
packets or Amiga receiver files were changed.

After building, check the static keyboard mapping by double-clicking `SELFTEST.cmd`
(or run the executable directly):

```
HDMIKVM.exe --selftest-keys
```

Expected: `Keyboard map self-test PASS (RSHIFT; LWIN->LAMIGA; MENU->RAMIGA; LALT->LALT)`.
This test exercises mapping logic but does not replace an actual Windows
keyboard/hardware test. Verify Right Shift + A, Right Shift + 1, and both
Shift keys in AmigaOS with HDMI input `17`.

## Architecture

- Source selection: Windows DXVA2 / DDC/CI VCP `0x60`, adapted from the hardware-validated HDMIInputProbe POC1. **Read only; never changes monitor input.**
- Mouse: Windows **Raw Input** background capture, relative X/Y (usable when the Windows cursor reaches the edge), primary/middle/secondary buttons, wheel mapped to Amiga Up/Down keys.
- Keyboard: `WH_KEYBOARD_LL` hook, mapping physical PC Set-1 scan positions into Amiga RAWKEY codes. Repeated key-down events are forwarded as repeats. Caps Lock is emulated locally with a temporary Amiga Shift.
- Local Windows mouse suppression: `WH_MOUSE_LL`; keyboard suppression: `WH_KEYBOARD_LL`. Hook processing is short, with network sends on a separate thread.
- Network: UDP/IPv4 port `6800`, **exactly the pre-existing AKVM version 1 protocol**. This sender never transmits `PKT_RESET`.
- Amiga: `l3-netkeys` uses `bsdsocket.library` + `IND_WRITEEVENT` in `input.device`, with no kernel or driver modifications.

## Preconditions

1. Windows 10 or 11 with .NET Framework 4.x, a directly connected DDC/CI-accessible display, and monitor/source values confirmed with POC1.
2. AmigaOS with MiamiDX/Roadshow or another compatible `bsdsocket.library` TCP/IP stack, reachable via IPv4 from Windows.
3. A **trusted/isolated local network**. This is a prototype; AKVM v1 is **not authenticated or encrypted**. Importantly, the original Amiga receiver accepts a network `RESET` packet (type 6) and calls `ColdReboot()`. **Never expose UDP/6800 to the Internet or an untrusted LAN.** Prefer a firewall rule allowing packets only from your Windows PC, or a private dedicated link.
4. Keep a physical Amiga keyboard/mouse available for initial tests, if possible. Always remember the Windows release hotkey.

## Build (Windows)

Unzip to a regular folder (e.g. `C:\HDMIKVM-POC2`). Double-click `BUILD.cmd` or run it from Command Prompt. Requires no Visual Studio, NuGet or Python; uses the .NET Framework v4 `csc.exe` included on many Windows installations.

Output: `HDMIKVM.exe` (C#/.NET Framework). The ZIP intentionally does **not** contain an executable compiled on an untested platform.

If build fails, capture the full compiler output and supply it for a fix.

## Setup (Amiga)

Transfer the existing binary `amiga-original/l3-netkeys` to the Amiga. Go online with MiamiDX / Roadshow, then in an Amiga Shell:

```
l3-netkeys
```

This listens on UDP port 6800. Terminate cleanly with Ctrl+C when testing finishes; the program attempts an `all_keys_up` on exit. Confirm that the Amiga IP is reachable from Windows.

## Windows — phase 1: detect only

```
BUILD.cmd
HDMIKVM.exe --list
HDMIKVM.exe --host 192.168.1.29 --monitor 0 --target 17 --interval 1000
```

Or double-click `WATCH.cmd` (prompts for Amiga IP).

No `--capture` means no keyboard/mouse interception and **no forwarding**. Verify these events by changing the monitor's physical input:

- Windows input `16`: Windows input remains local.
- HDMI switching: `VCP UNKNOWN` for ~2–3 seconds, **not** interpreted as Amiga.
- Amiga input `17`, read twice: `AMIGA SOURCE DETECTED`.
- Back to Windows `16`, read twice: `WINDOWS INPUT RESTORED`.

## Windows — phase 2: enable input forwarding

When phase 1 is good and `l3-netkeys` is running on the Amiga:

```
HDMIKVM.exe --host 192.168.1.29 --monitor 0 --target 17 --windows-source auto --interval 1000 --capture
```

Or run `KVM.cmd 192.168.1.29 17` (exactly two positional arguments; auto-detects the current Windows source). **Start it while Windows is the visible monitor input.**

### FIX1: strict normal-desktop input routing

| Monitor status | Local Windows mouse & keyboard | Amiga UDP injection |
| --- | --- | --- |
| Two consecutive readings `16` (Windows) | ALLOWED | Disabled |
| `UNKNOWN`, first source reading, nonconfigured source, or unconfirmed change | **SUPPRESSED** (quarantine) | **Disabled** |
| Two consecutive readings `17` (Amiga) | **SUPPRESSED** | Enabled |
| Missing/blocked DDC/CI poll | **SUPPRESSED** after a short watchdog timeout | Disabled |
| Emergency `Ctrl+Alt+Shift+F12` | ALLOWED (manual override) | Disabled |

- Keyboard suppression uses `WH_KEYBOARD_LL`. Mouse messages (movement, clicks and wheel) use `WH_MOUSE_LL` suppression while physical mouse movement/buttons are read from Raw Input for forwarding to Amiga.
- On the very first `UNKNOWN`, forwarding stops and a repeated `ALLUP` sequence releases remote keys. **It does not silently restore Windows input.**
- Windows input returns automatically **only** on two consecutive readings of the Windows input captured at startup (e.g. `16`). The `--windows-source` option can alternatively set a fixed source.
- The UI-thread watchdog detects a stuck DDC/CI call after `max(1500, 3 x poll_interval)` milliseconds without a valid reading; it enters quarantine, **not** Windows mode. The maximum poll interval is 2000 ms in both capture and watch-only modes.
- For safety the program begins in quarantine until a destination has been confirmed. After FIX3 first detects the baseline in read-only startup mode, input hooks are installed and there may still be a brief quarantine while Windows is reconfirmed.
- On program exit / emergency release, forwarding stops and repeated `ALLUP` is sent.

**Important limitations:** The program cannot detect the physical instant the monitor input switches. Until the next DDC/CI result/watchdog threshold, there is a small unavoidable exposure interval. Nor can user-mode Win32 hooks provide absolute isolation for secure Windows desktops (`Ctrl+Alt+Del`, UAC), apps using Raw Input directly, special system input, or hooks that Windows silently removes after a timeout. Therefore **"no local Windows input whatsoever" is not guaranteed** by this POC. If absolute isolation is a hard requirement, physical KVM/hardware switching or a lower-level HID driver design is needed. For the first test, leave a harmless text editor window open on Windows and verify it receives no keystrokes, mouse clicks, or scroll while Amiga source 17 is active before using any sensitive app.

### Emergency release

**Press `Ctrl+Alt+Shift+F12`** to immediately return keyboard/mouse to Windows, even when HDMI still points at Amiga. To re-enable forwarding after this manual pause, first switch monitor to the Windows source detected at startup, let it be confirmed twice, then switch back to the Amiga source. `Ctrl+Alt+Del` also remains a Windows secure-attention sequence, although it is not an intended control interface for this POC.

Stop the program with `Ctrl+C` when Windows has regained input, or close the console. The hooks are not drivers and go away if the process terminates, but abrupt termination can leave remote Amiga keys held because the existing receiver has no automatic heartbeat timeout.

### Optional flags

- `--port 6800` : receiving Amiga UDP port
- `--mouse-scale 1.0` : relative mouse multiplier
- `--wheel-steps 3` : Amiga cursor-key pulses per wheel notch
- `--interval 1000` : DDC poll gap in ms (250–2000)
- `--target 17` : target HDMI source (accepts `0x11` too)
- `--windows-source auto` : detect the current Windows monitor input before capture (used by `KVM.cmd`)
- `--windows-source 16` : optional manually specified Windows input for direct `HDMIKVM.exe` use
- `--monitor 0` : index from `--list`

## Protocol compatibility

All network byte fields are unchanged:

```
AKVM header: [A,K,V,M] [version=1] [type] [seq_hi] [seq_lo]
KEY type=1:     [rawcode] [down=1|up=0]
ALLUP type=4:   empty payload
HEARTBEAT type=5: empty payload
MOUSE2 type=7:  [dx_hi, dx_lo, dy_hi, dy_lo, buttons]
```

`dx`, `dy`: signed 16-bit big-endian; `buttons`: bit 0 left, bit 1 right, bit 2 middle. All packet sequence numbers increase for each datagram. `PKT_RESET` exists in the old receiver but is intentionally omitted from the Windows sender.

## Limitations / validation status

- The *DDC/CI source detection* is hardware-confirmed in POC1, including a transient UNKNOWN during switching followed by a stable `17` on the Amiga source.
- **FIX3 was hardware-validated by the user (including automatic Windows input detection). FIX5 changes only key mapping; FIX6 additionally changes the polling defaults/limits, and neither is independently hardware-validated by this packaging step.** Windows UAC secure desktop, elevated windows, injected events, and some special keys may not be captured or suppressed as normal user-level input.
- Relative Raw Input supports common physical USB/Bluetooth mice. Absolute-position devices/tablets are ignored for movement in this POC.
- International keyboard key positions and complex Caps Lock + Shift combinations may need refinement.
- UDP can reorder/drop packets; the legacy Amiga receiver only discards exact last-sequence duplicates and **does not expire stuck keys on heartbeat loss**. Repeated ALLUP helps but is not a guarantee. A receiver watchdog / sender restriction should be added once initial hardware validation succeeds.
- This is an attended, foreground console prototype, not an unattended Windows Service or production security tool.
