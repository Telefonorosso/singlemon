@echo off
if not exist "%~dp0HDMIKVM.exe" call "%~dp0BUILD.cmd" || exit /b 1
set /p "AMIGA_IP=Amiga IPv4 address: "
"%~dp0HDMIKVM.exe" --host "%AMIGA_IP%" --monitor 0 --target 17 --windows-source 16
pause
