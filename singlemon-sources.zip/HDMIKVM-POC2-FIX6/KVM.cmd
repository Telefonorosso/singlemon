@echo off
setlocal
rem Usage: KVM.cmd AMIGA_IPV4 AMIGA_HDMI_SOURCE
rem The HDMI input currently selected at startup becomes the Windows source.
if "%~1"=="" goto usage
if "%~2"=="" goto usage
if not "%~3"=="" goto usage
rem Production launcher: never rebuild on launch. Build.cmd must be run once after installing this FIX.
if not exist "%~dp0HDMIKVM.exe" (
  echo ERROR: HDMIKVM.exe not found in "%~dp0".
  echo Run BUILD.cmd once to compile this version, then retry.
  exit /b 1
)

echo Windows HDMI source will be detected from the monitor at startup.
echo Amiga IP: %~1  ^|  Amiga HDMI source: %~2
echo Emergency: Ctrl+Alt+Shift+F12 restores local Windows input.
echo.
"%~dp0HDMIKVM.exe" --host "%~1" --monitor 0 --target "%~2" --windows-source auto --capture
exit /b %errorlevel%

:usage
echo Usage: %~nx0 AMIGA_IPV4 AMIGA_HDMI_SOURCE
echo Example: %~nx0 192.168.1.29 17
echo Example: %~nx0 192.168.1.29 0x11
echo Exactly two arguments are required. Start while Windows is on screen.
exit /b 2
