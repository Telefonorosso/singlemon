@echo off
setlocal
cd /d "%~dp0"
if not exist HDMIKVM.exe call BUILD.cmd
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
HDMIKVM.exe --selftest-keys
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" (echo Mapping test passed.) else (echo Mapping test FAILED.)
pause
exit /b %RESULT%
